# functions that might be useful

 * `_mm_add_epi32`
 * `_mm_slli_epi32`
 * `_mm_srli_epi32`
 * `_mm_set1_epi32`
 * `_mm_cmpeq_epi32`
 * `_mm_movemask_epi8`

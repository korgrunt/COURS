#define PWD_LEN 7
